#!/usr/bin/env bash
# Started by HiveOS in a screen session; must stay in the foreground.
cd "$(dirname "$0")" || exit 1
. ./h-manifest.conf
. "$CUSTOM_CONFIG_FILENAME" || { echo "config missing: apply the flight sheet again"; exit 1; }

LOG="${CUSTOM_LOG_BASENAME}.log"
mkdir -p "$(dirname "$LOG")"
[ -f "$LOG" ] && [ "$(stat -c %s "$LOG")" -gt 52428800 ] && : > "$LOG"      # keep the log small

glibc="$(ldd --version 2>&1 | head -n1 | grep -oE '[0-9]+\.[0-9]+$')"
if [ "$(printf '%s\n%s\n' 2.35 "${glibc:-0}" | sort -V | head -n1)" != "2.35" ]; then
  echo "This HiveOS image is too old (glibc ${glibc:-unknown}, need 2.35+). Update to a HiveOS image based on Ubuntu 22.04 or newer." | tee -a "$LOG"
  exit 1
fi

# Use only GPUs the miner has code for (compute capability >= 7.0) and pick launch values per GPU generation.
GOOD=(); NEWARCH=0; VOLTA=0; BLACKWELL=0
while IFS=, read -r idx cap; do
  idx="${idx// /}"; cap="${cap// /}"; major="${cap%%.*}"
  case "$major" in ''|*[!0-9]*) continue ;; esac
  if [ "$major" -ge 7 ]; then
    GOOD+=("$idx")
    [ "$(printf '%s\n%s\n' 8.9 "$cap" | sort -V | head -n1)" = "8.9" ] && NEWARCH=1
    [ "$cap" = "7.0" ] && VOLTA=1
    [ "$major" -ge 12 ] && BLACKWELL=1
  fi
done < <(nvidia-smi --query-gpu=index,compute_cap --format=csv,noheader 2>/dev/null)
if [ "${#GOOD[@]}" -eq 0 ]; then
  echo "No supported GPU (V100, RTX 20/30/40/50 series, CMP 50HX; compute capability 7.0+) found." | tee -a "$LOG"; exit 1
fi
GPU_LIST="$(IFS=,; echo "${GOOD[*]}")"
echo "$GPU_LIST" > "$PWD/gpus.used"
if [ "$NEWARCH" -eq 1 ]; then TPB=640; elif [ "$VOLTA" -eq 1 ]; then TPB=512; else TPB=768; fi

# v30 is one unified build (CUDA 12.9 runtime; the RTX 50-series kernel is CUDA 13.2 and needs driver 580+).
# A cuda13/ folder left over from v29.0.1 is ignored.
driver="$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -n1 | cut -d. -f1)"
BIN_DIR="$PWD"
case "$driver" in ''|*[!0-9]*) ;; *) [ "$BLACKWELL" -eq 1 ] && [ "$driver" -lt 580 ] && \
  echo "RTX 50 series needs NVIDIA driver 580 or newer (found $driver). Update the driver." | tee -a "$LOG" ;; esac
echo "NVIDIA driver ${driver:-unknown}: using $BIN_DIR/zk-pow-mine" | tee -a "$LOG"

export LD_LIBRARY_PATH="$BIN_DIR:$LD_LIBRARY_PATH" NO_COLOR=1
# shellcheck disable=SC2086   # EXTRA is intentionally word-split
"$BIN_DIR/zk-pow-mine" --pool-addr "$POOL" --pool-key "$KEY" --pool-hashrate --cuda-devices "$GPU_LIST" \
  --cuda-blocks-per-sm 1 --cuda-threads-per-block "$TPB" --cuda-batch-size 4194304 \
  --reconnect-max-attempts 1000000 $EXTRA 2>&1 | tee -a "$LOG"
