#!/usr/bin/env bash
# Sourced by HiveOS when the flight sheet is applied.
# Flight sheet fields used: CUSTOM_TEMPLATE (= <TOKEN>.<WORKER>), CUSTOM_URL (pool), CUSTOM_USER_CONFIG (extra args).
. "$(dirname "${BASH_SOURCE[0]}")/h-manifest.conf"

if [[ -z $CUSTOM_TEMPLATE ]]; then
  echo -e "${YELLOW:-}CUSTOM_TEMPLATE is empty. Set 'Wallet and worker template' to %WAL%.%WORKER_NAME%${NOCOLOR:-}"
  return 1 2>/dev/null || exit 1
fi
[[ -z $CUSTOM_URL ]] && CUSTOM_URL="pool.nockmining.com:27016"
CUSTOM_URL="${CUSTOM_URL#*://}"          # the miner wants host:port without a scheme

mkdir -p "$(dirname "$CUSTOM_CONFIG_FILENAME")"
umask 077
{
  printf 'POOL=%q\n' "$CUSTOM_URL"
  printf 'KEY=%q\n' "$CUSTOM_TEMPLATE"
  printf 'EXTRA=%q\n' "$CUSTOM_USER_CONFIG"
} > "$CUSTOM_CONFIG_FILENAME"
