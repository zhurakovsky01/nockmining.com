NOCK pool custom miner v30.3 (2026-10-10)
v30 unified build, one binary for Volta, Turing, Ampere, Ada and Blackwell; two CUDA sessions per GPU; default pool batch 4M.
Supported: V100 (sm_70), RTX 20 / CMP 50HX (sm_75), RTX 30 (sm_86), RTX 40 (sm_89), RTX 50 (sm_120).
Use an Ubuntu 22.04+ based HiveOS image with a compatible NVIDIA driver. RTX 50-series needs NVIDIA driver 580 or newer.
v30.3: Performance improvements for RTX 30/40 series, new console view, and minor improvements; GPU code for sm_70/75/80/120 is byte-identical to v30.0.
The console view is used only on a terminal; under HiveOS (piped output) the plain log lines are unchanged, so the stats parser needs no change.
v30.0: adds V100, RTX 20-series and CMP 50HX; RTX 30/40/50 keep their existing performance (50-series includes the v29.0.1 +3%).
A100/A30 cubins are included; native hardware validation is not available.
Flight sheet: Custom miner; Wallet/worker template = %WAL%.%WORKER_NAME%
Pool URL = pool.nockmining.com:27016
zk-pow-mine: CUDA 12.9 runtime; its RTX 50-series kernel is CUDA 13.2 (driver 580+ required), others CUDA 12.9.
The separate cuda13/ build of v29.0.1 is replaced by this unified binary.
Use your own receiving address. Never use an exchange deposit address.
