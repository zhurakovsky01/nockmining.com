#!/usr/bin/env bash
# Sourced by HiveOS every ~30 s. Must set: khs (total, in kH/s) and stats (JSON).
DIR="$(dirname "${BASH_SOURCE[0]}")"
. "$DIR/h-manifest.conf"
LOG="${CUSTOM_LOG_BASENAME}.log"

khs=0
stats=""
pid="$(pgrep -x zk-pow-mine | head -n1)"
if [[ -n $pid && -f $LOG ]]; then
  # last reported MH/s per device, in device order
  mapfile -t rates < <(tail -n 800 "$LOG" | grep 'hashrate device=' | awk '{
      match($0,/device=[0-9]+/); d=substr($0,RSTART+7,RLENGTH-7)+0;
      match($0,/mhs="[0-9.]+"/); m=substr($0,RSTART+5,RLENGTH-6)+0; last[d]=m }
    END { for (d in last) print d, last[d] }' | sort -n | awk '{print $2}')

  used=(); [[ -f $DIR/gpus.used ]] && IFS=, read -r -a used < "$DIR/gpus.used"
  total="$(nvidia-smi -L 2>/dev/null | wc -l)"; [[ $total -lt 1 ]] && total=${#rates[@]}
  hs=(); for ((i=0;i<total;i++)); do hs[i]=0; done
  for i in "${!rates[@]}"; do
    slot="${used[i]:-$i}"; hs[slot]="${rates[i]}"
  done
  sum=0; for v in "${hs[@]}"; do sum="$(awk -v a="$sum" -v b="$v" 'BEGIN{printf "%.4f", a+b}')"; done
  khs="$(awk -v s="$sum" 'BEGIN{printf "%.2f", s*1000}')"

  hs_json="$(printf '%s\n' "${hs[@]}" | jq -sc '.')"
  temp="$(jq -c '.temp // []' <<< "${gpu_stats:-{\}}" 2>/dev/null)"; [[ -z $temp ]] && temp='[]'
  fan="$(jq -c '.fan // []' <<< "${gpu_stats:-{\}}" 2>/dev/null)"; [[ -z $fan ]] && fan='[]'
  acc="$(grep -c 'accepted=true' "$LOG")"; rej="$(grep -c 'accepted=false' "$LOG")"
  uptime="$(ps -o etimes= -p "$pid" | tr -d ' ')"
  stats="$(jq -nc --argjson hs "$hs_json" --argjson temp "$temp" --argjson fan "$fan" \
      --argjson up "${uptime:-0}" --argjson acc "${acc:-0}" --argjson rej "${rej:-0}" --arg ver "$CUSTOM_VERSION" \
      '{hs:$hs, hs_units:"mhs", temp:$temp, fan:$fan, uptime:$up, ar:[$acc,$rej], algo:"nockchain", ver:$ver}')"
fi
[[ -z $khs ]] && khs=0
